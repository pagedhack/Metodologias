from tkinter import *
from tkinter import messagebox
from tkinter import ttk
import mysql.connector
import random
import string
import os

class Shoe:
    def __init__(self, model, size, color, stock):
        self.model = model
        self.size = size
        self.color = color
        self.stock = stock
        self.code = self.generate_code()

    def generate_code(self):
        code = ''.join(random.choices(string.ascii_uppercase + string.digits, k=6))
        return code

    def __str__(self):
        return f'{self.code} {self.model} {self.size} {self.color} {self.stock}'

class Menu:
    def __init__(self):
        self.window = Tk()
        self.window.title('Shoes')
        self.window.geometry('500x500')
        self.window.resizable(0, 0)
        self.window.config(bg='#f2f2f2')

        self.frame = Frame(self.window, bg='#f2f2f2')
        self.frame.pack(fill='both', expand=1)

        self.label_title = Label(self.frame, text='Shoes', font=('Arial', 20), bg='#f2f2f2')
        self.label_title.place(x=200, y=20)

        self.button_register = Button(self.frame, text='Register', font=('Arial', 15), bg='#f2f2f2', command=self.register)
        self.button_register.place(x=200, y=100)

        self.button_modify = Button(self.frame, text='Modify', font=('Arial', 15), bg='#f2f2f2', command=self.modify)
        self.button_modify.place(x=200, y=150)

        self.button_delete = Button(self.frame, text='Delete', font=('Arial', 15), bg='#f2f2f2', command=self.delete)
        self.button_delete.place(x=200, y=200)

        self.button_exit = Button(self.frame, text='Exit', font=('Arial', 15), bg='#f2f2f2', command=self.window.destroy)
        self.button_exit.place(x=200, y=250)

        self.window.mainloop()

    def register(self):
        self.window_register = Tk()
        self.window_register.title('Register')
        self.window_register.geometry('500x500')
        self.window_register.resizable(0, 0)
        self.window_register.config(bg='#f2f2f2')

        self.frame_register = Frame(self.window_register, bg='#f2f2f2')
        self.frame_register.pack(fill='both', expand=1)

        self.label_title_register = Label(self.frame_register, text='Register', font=('Arial', 20), bg='#f2f2f2')
        self.label_title_register.place(x=200, y=20)

        self.label_model = Label(self.frame_register, text='Model', font=('Arial', 15), bg='#f2f2f2')
        self.label_model.place(x=50, y=100)

        self.entry_model = Entry(self.frame_register, font=('Arial', 15), bg='#f2f2f2')
        self.entry_model.place(x=200, y=100)

        self.label_size = Label(self.frame_register, text='Size', font=('Arial', 15), bg='#f2f2f2')
        self.label_size.place(x=50, y=150)

        self.entry_size = Entry(self.frame_register, font=('Arial', 15), bg='#f2f2f2')
        self.entry_size.place(x=200, y=150)

        self.label_color = Label(self.frame_register, text='Color', font=('Arial', 15), bg='#f2f2f2')
        self.label_color.place(x=50, y=200)

        self.entry_color = Entry(self.frame_register, font=('Arial', 15), bg='#f2f2f2')
        self.entry_color.place(x=200, y=200)

        self.label_stock = Label(self.frame_register, text='Stock', font=('Arial', 15), bg='#f2f2f2')
        self.label_stock.place(x=50, y=250)

        self.entry_stock = Entry(self.frame_register, font=('Arial', 15), bg='#f2f2f2')
        self.entry_stock.place(x=200, y=250)

        self.button_register_register = Button(self.frame_register, text='Register', font=('Arial', 15), bg='#f2f2f2', command=self.register_register)
        self.button_register_register.place(x=200, y=300)

        self.button_exit_register = Button(self.frame_register, text='Exit', font=('Arial', 15), bg='#f2f2f2', command=self.window_register.destroy)
        self.button_exit_register.place(x=200, y=350)

        self.window_register.mainloop()

    def register_register(self):
        model = self.entry_model.get()
        size = self.entry_size.get()
        color = self.entry_color.get()
        stock = self.entry_stock.get()

        if model == '' or size == '' or color == '' or stock == '':
            messagebox.showwarning('Warning', 'All fields are required')
        else:
            shoe = Shoe(model, size, color, stock)
            file = open('shoes.txt', 'a')
            file.write(f'{shoe}\n')
            file.close()
            messagebox.showinfo('Information', 'Shoe registered')
            self.entry_model.delete(0, END)
            self.entry_size.delete(0, END)
            self.entry_color.delete(0, END)
            self.entry_stock.delete(0, END)

    def modify(self):
        self.window_modify = Tk()
        self.window_modify.title('Modify')
        self.window_modify.geometry('500x500')
        self.window_modify.resizable(0, 0)
        self.window_modify.config(bg='#f2f2f2')

        self.frame_modify = Frame(self.window_modify, bg='#f2f2f2')
        self.frame_modify.pack(fill='both', expand=1)

        self.label_title_modify = Label(self.frame_modify, text='Modify', font=('Arial', 20), bg='#f2f2f2')
        self.label_title_modify.place(x=200, y=20)

        self.label_code = Label(self.frame_modify, text='Code', font=('Arial', 15), bg='#f2f2f2')
        self.label_code.place(x=50, y=100)

        self.entry_code = Entry(self.frame_modify, font=('Arial', 15), bg='#f2f2f2')
        self.entry_code.place(x=200, y=100)

        self.label_model = Label(self.frame_modify, text='Model', font=('Arial', 15), bg='#f2f2f2')
        self.label_model.place(x=50, y=150)

        self.entry_model = Entry(self.frame_modify, font=('Arial', 15), bg='#f2f2f2')
        self.entry_model.place(x=200, y=150)

        self.label_size = Label(self.frame_modify, text='Size', font=('Arial', 15), bg='#f2f2f2')
        self.label_size.place(x=50, y=200)

        self.entry_size = Entry(self.frame_modify, font=('Arial', 15), bg='#f2f2f2')
        self.entry_size.place(x=200, y=200)

        self.label_color = Label(self.frame_modify, text='Color', font=('Arial', 15), bg='#f2f2f2')
        self.label_color.place(x=50, y=250)

        self.entry_color = Entry(self.frame_modify, font=('Arial', 15), bg='#f2f2f2')
        self.entry_color.place(x=200, y=250)

        self.label_stock = Label(self.frame_modify, text='Stock', font=('Arial', 15), bg='#f2f2f2')
        self.label_stock.place(x=50, y=300)

        self.entry_stock = Entry(self.frame_modify, font=('Arial', 15), bg='#f2f2f2')
        self.entry_stock.place(x=200, y=300)

        self.button_modify_modify = Button(self.frame_modify, text='Modify', font=('Arial', 15), bg='#f2f2f2', command=self.modify_modify)
        self.button_modify_modify.place(x=200, y=350)

        self.button_exit_modify = Button(self.frame_modify, text='Exit', font=('Arial', 15), bg='#f2f2f2', command=self.window_modify.destroy)
        self.button_exit_modify.place(x=200, y=400)

        self.window_modify.mainloop()

    def modify_modify(self):
        code = self.entry_code.get()
        model = self.entry_model.get()
        size = self.entry_size.get()
        color = self.entry_color.get()
        stock = self.entry_stock.get()

        if code == '' or model == '' or size == '' or color == '' or stock == '':
            messagebox.showwarning('Warning', 'All fields are required')
        else:
            file = open('shoes.txt', 'r')
            lines = file.readlines()
            file.close()
            file = open('shoes.txt', 'w')
            for line in lines:
                if line.split()[0] == code:
                    file.write(f'{code} {model} {size} {color} {stock}\n')
                else:
                    file.write(line)
            file.close()
            messagebox.showinfo('Information', 'Shoe modified')
            self.entry_code.delete(0, END)
            self.entry_model.delete(0, END)
            self.entry_size.delete(0, END)
            self.entry_color.delete(0, END)
            self.entry_stock.delete(0, END)

    def delete(self):
        self.window_delete = Tk()
        self.window_delete.title('Delete')
        self.window_delete.geometry('500x500')
        self.window_delete.resizable(0, 0)
        self.window_delete.config(bg='#f2f2f2')

        self.frame_delete = Frame(self.window_delete, bg='#f2f2f2')
        self.frame_delete.pack(fill='both', expand=1)

        self.label_title_delete = Label(self.frame_delete, text='Delete', font=('Arial', 20), bg='#f2f2f2')
        self.label_title_delete.place(x=200, y=20)

        self.label_code = Label(self.frame_delete, text='Code', font=('Arial', 15), bg='#f2f2f2')
        self.label_code.place(x=50, y=100)

        self.entry_code = Entry(self.frame_delete, font=('Arial', 15), bg='#f2f2f2')
        self.entry_code.place(x=200, y=100)

        self.button_delete_delete = Button(self.frame_delete, text='Delete', font=('Arial', 15), bg='#f2f2f2', command=self.delete_delete)
        self.button_delete_delete.place(x=200, y=150)

        self.button_exit_delete = Button(self.frame_delete, text='Exit', font=('Arial', 15), bg='#f2f2f2', command=self.window_delete.destroy)
        self.button_exit_delete.place(x=200, y=200)

        self.window_delete.mainloop()

    def delete_delete(self):
        code = self.entry_code.get()

        if code == '':
            messagebox.showwarning('Warning', 'All fields are required')
        else:
            file = open('shoes.txt', 'r')
            lines = file.readlines()
            file.close()
            file = open('shoes.txt', 'w')
            for line in lines:
                if line.split()[0] != code:
                    file.write(line)
            file.close()
            messagebox.showinfo('Information', 'Shoe deleted')
            self.entry_code.delete(0, END)

menu = Menu()